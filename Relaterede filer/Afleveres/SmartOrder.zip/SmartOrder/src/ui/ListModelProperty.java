package ui;

import java.util.ArrayList;

import javax.swing.DefaultListModel;

import model.*;

/**
 * SmartOrder
 * ListModelProperty.java
 * Purpose: //TODO WHAT IS THE PURPOSE OF THIS CLASS????
 * @author Gruppe 1
 * @version 1.0 
 */
public class ListModelProperty extends DefaultListModel {
	
	private ArrayList<Property> properties = new ArrayList<>();
	
//	@Override
//	public Object getElementAt(int index){
//		return properties.get(index).getName();
//		
//	}
//	
//	@Override
//	public String elementAt(int index){
//		return properties.get(index).getName();
//	}
//	
//	@Override
//	public void addElement(Object o){
//		properties.add((Property) o);
//	}
	
	

}
