package ui;

import javax.swing.AbstractListModel;

/**
 * SmartOrder
 * ListModelCustomer.java
 * Purpose: //TODO WHAT IS THE PURPOSE OF THIS CLASS?
 * @author Gruppe 1
 * @version 1.0 
 */
public class ListModelCustomer extends AbstractListModel {

	@Override
	public Object getElementAt(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}

}
