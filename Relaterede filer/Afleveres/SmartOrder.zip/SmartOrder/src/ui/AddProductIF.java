package ui;

import model.Product;

/**
 * SmartOrder
 * AddProductIF.java
 * Purpose: //TODO WHAT IS THE PURPOSE OF THIS CLASS?
 * @author Gruppe 1
 * @version 1.0 
 */
public interface AddProductIF {
	void addProduct(Product p, int amount);

}
