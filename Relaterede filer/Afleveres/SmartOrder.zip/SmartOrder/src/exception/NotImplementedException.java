package exception;

/**
 * SmartOrder
 * NotImplementedException.java
 * @author Gruppe 1
 * @version 1.0 
 */
public class NotImplementedException extends Exception {
	public NotImplementedException() {
		super("Funktionen er endnu ikke implementeret");
	}
}
